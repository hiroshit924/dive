<?php
/**
 * Plugin Name: Dive 365 Shop
 * Description: Bilingual calendar, booking requests and emails, and legacy post type support.
 * Version: 1.9.0
 * Requires PHP: 8.1
 */

defined('ABSPATH') || exit;

require __DIR__ . '/booking-mail.php';

function d365_is_english(): bool {
    return get_query_var('d365_lang') === 'en';
}

function d365_text(string $ja, string $en): string {
    return d365_is_english() ? $en : $ja;
}

function d365_home(bool $english, array $args = []): string {
    if ($english) {
        if (get_option('permalink_structure')) {
            return add_query_arg($args, home_url('/en/'));
        }
        $args['d365_lang'] = 'en';
    }
    return add_query_arg($args, home_url('/'));
}

function d365_register(): void {
    add_rewrite_rule('^en/privacy/?$', 'index.php?d365_lang=en&d365_privacy=1', 'top');
    add_rewrite_rule('^privacy/?$', 'index.php?d365_privacy=1', 'top');
    add_rewrite_rule('^en/michael/?$', 'index.php?d365_lang=en&d365_michael=1', 'top');
    add_rewrite_rule('^michael/?$', 'index.php?d365_michael=1', 'top');
    add_rewrite_rule('^en/discover-scuba/?$', 'index.php?d365_lang=en&d365_experience=trial', 'top');
    add_rewrite_rule('^en/dive-trips/overseas/?$', 'index.php?d365_lang=en&d365_experience=overseas', 'top');
    add_rewrite_rule('^dive-trips/overseas/?$', 'index.php?d365_experience=overseas', 'top');
    add_rewrite_rule('^en/dive-trips/(miura-zushi-hayama|izu|hatsushima)/?$', 'index.php?d365_lang=en&d365_experience=tour&d365_tour_area=$matches[1]', 'top');
    add_rewrite_rule('^dive-trips/(miura-zushi-hayama|izu|hatsushima)/?$', 'index.php?d365_experience=tour&d365_tour_area=$matches[1]', 'top');
    add_rewrite_rule('^en/dive-trips/?$', 'index.php?d365_lang=en&d365_experience=tour', 'top');
    $courses = '(open-water|advanced|specialties|efr|rescue|divemaster)';
    add_rewrite_rule('^en/courses/' . $courses . '/?$', 'index.php?d365_lang=en&d365_courses=1&d365_course=$matches[1]', 'top');
    add_rewrite_rule('^courses/' . $courses . '/?$', 'index.php?d365_courses=1&d365_course=$matches[1]', 'top');
    add_rewrite_rule('^en/courses/?$',  'index.php?d365_lang=en&d365_courses=1', 'top');
    add_rewrite_rule('^en/?$', 'index.php?d365_lang=en', 'top');

    // Preserve the post types and query URLs used by the previous theme.
    foreach (['diving_blog' => 'ダイビングブログ', 'news' => 'お知らせ'] as $type => $label) {
        if (!post_type_exists($type)) {
            register_post_type($type, [
                'label' => $label, 'public' => true, 'has_archive' => true,
                'show_in_rest' => true, 'rewrite' => ['slug' => $type],
                'supports' => ['title', 'editor', 'thumbnail', 'excerpt', 'author', 'comments', 'revisions', 'custom-fields'],
            ]);
        }
    }

    register_post_type('d365_session', [
        'label' => 'ダイビング日程', 'show_ui' => true, 'public' => false,
        'supports' => ['title'], 'menu_icon' => 'dashicons-calendar-alt',
        'labels' => ['add_new_item' => 'ダイビング日程を追加', 'edit_item' => 'ダイビング日程を編集'],
    ]);

    register_post_type('d365_booking', [
        'label' => 'ダイビング予約', 'show_ui' => true, 'public' => false,
        'supports' => ['title'], 'menu_icon' => 'dashicons-clipboard',
        'capability_type' => ['d365_booking', 'd365_bookings'], 'map_meta_cap' => true,
        'capabilities' => [
            'create_posts' => 'do_not_allow',
            'edit_posts' => 'manage_options',
            'edit_others_posts' => 'manage_options',
            'edit_published_posts' => 'manage_options',
            'edit_private_posts' => 'manage_options',
            'read_private_posts' => 'manage_options',
            'delete_posts' => 'manage_options',
            'delete_others_posts' => 'manage_options',
            'delete_published_posts' => 'manage_options',
            'delete_private_posts' => 'manage_options',
        ],
    ]);
}
add_action('init', 'd365_register', 20);
function d365_refresh_rewrite_rules(): void {
    if (get_option('d365_rewrite_version') !== '7') {
        flush_rewrite_rules(false);
        update_option('d365_rewrite_version', '7');
    }
}
add_action('wp_loaded', 'd365_refresh_rewrite_rules');
register_activation_hook(__FILE__, static function (): void {
    d365_register();
    flush_rewrite_rules(false);
    update_option('d365_rewrite_version', '7');
});
add_filter('query_vars', static function (array $vars): array {
    $vars[] = 'd365_lang';
    $vars[] = 'd365_courses';
    $vars[] = 'd365_course';
    $vars[] = 'd365_experience';
    $vars[] = 'd365_tour_area';
    $vars[] = 'd365_michael';
    $vars[] = 'd365_privacy';
    return $vars;
});
add_filter('request', static function (array $vars): array {
    if (($vars['d365_lang'] ?? '') === 'en' && count($vars) === 1 && get_option('show_on_front') === 'page') {
        $vars['page_id'] = (int) get_option('page_on_front');
    }
    return $vars;
});
add_filter('redirect_canonical', static function ($redirect) {
    return ((d365_is_english() && is_front_page()) || get_query_var('d365_courses') === '1' || get_query_var('d365_michael') === '1' || get_query_var('d365_privacy') === '1' || in_array(get_query_var('d365_experience'), ['trial', 'tour', 'overseas'], true)) ? false : $redirect;
});

add_action('template_redirect', static function (): void {
    if (is_front_page()) {
        nocache_headers();
    }
});

function d365_now(): DateTimeImmutable {
    return new DateTimeImmutable('now', new DateTimeZone('Asia/Tokyo'));
}

function d365_date(string $value, string $format = 'Y-m-d'): ?DateTimeImmutable {
    $date = DateTimeImmutable::createFromFormat('!' . $format, $value, d365_now()->getTimezone());
    return $date && $date->format($format) === $value ? $date : null;
}

function d365_input(array $input, string $key): string {
    return isset($input[$key]) && is_string($input[$key]) ? wp_unslash($input[$key]) : '';
}

function d365_services(?bool $english = null): array {
    return ($english ?? d365_is_english())
        ? ['trial' => 'Discover Scuba Diving', 'course' => 'Scuba Certification', 'tour' => 'Fun Dive Trips']
        : ['trial' => '体験ダイビング', 'course' => 'ライセンス講習', 'tour' => 'ファンダイブツアー'];
}

function d365_inquiry_topics(?bool $english = null): array {
    $english ??= d365_is_english();
    return d365_services($english) + ['other' => $english ? 'Other inquiries' : 'その他のご相談'];
}

function d365_statuses(): array {
    return ['pending' => '未対応', 'confirmed' => '確定', 'declined' => '受付不可', 'cancelled' => 'キャンセル'];
}

function d365_session_title(WP_Post $event): string {
    $translation = (string) get_post_meta($event->ID, '_d365_en', true);
    return d365_is_english() && $translation !== '' ? $translation : $event->post_title;
}

function d365_session_dates(int $id): array {
    $start = d365_date((string) get_post_meta($id, '_d365_date', true));
    $end = d365_date((string) get_post_meta($id, '_d365_end_date', true));
    return [$start, $start && $end && $end >= $start ? $end : $start];
}

function d365_booking_period(int $id): string {
    $start = (string) get_post_meta($id, '_d365_session_date', true);
    $end = (string) get_post_meta($id, '_d365_session_end_date', true);
    return $start !== '' && $end > $start ? $start . ' – ' . $end : $start;
}

function d365_sessions(): array {
    return get_posts([
        'post_type' => 'd365_session', 'post_status' => 'publish', 'posts_per_page' => -1,
        'meta_key' => '_d365_date', 'orderby' => ['meta_value' => 'ASC', 'ID' => 'ASC'],
    ]);
}

function d365_session_open(WP_Post $event): bool {
    $date = (string) get_post_meta($event->ID, '_d365_date', true);
    return $event->post_type === 'd365_session' && $event->post_status === 'publish'
        && d365_date($date) && $date >= d365_now()->format('Y-m-d')
        && get_post_meta($event->ID, '_d365_availability', true) === 'open';
}

function d365_open_booking_session(string $value): ?WP_Post {
    $id = filter_var($value, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    $event = $id ? get_post($id) : null;
    return $event && d365_session_open($event) ? $event : null;
}

function d365_session_icons(): array {
    return [
        'mask' => 'ダイビングマスク',
        'island' => '南の島',
        'beach' => 'ビーチ',
        'boat' => 'ボート',
        'waves' => '波',
        'fish' => '熱帯魚',
        'turtle' => 'ウミガメ',
        'coral' => 'サンゴ',
        'shark' => 'サメ',
        'compass' => 'コンパス',
    ];
}

function d365_session_icon(int $id): string {
    $icon = (string) get_post_meta($id, '_d365_session_icon', true);
    return isset(d365_session_icons()[$icon]) ? $icon : 'mask';
}

function d365_session_icon_url(string $icon): string {
    return plugins_url('assets/session-icons/' . $icon . '.png', __FILE__);
}

add_action('admin_enqueue_scripts', static function (string $page): void {
    if (in_array($page, ['post.php', 'post-new.php'], true) && get_current_screen()?->post_type === 'd365_session') {
        wp_enqueue_style('d365-session-icons', plugins_url('assets/session-icons-admin.css', __FILE__), [], '1.8.0');
    }
});

add_action('add_meta_boxes', static function (): void {
    add_meta_box('d365_session', '開催日程の設定', 'd365_session_box', 'd365_session');
    add_meta_box('d365_booking', '予約申請の詳細', 'd365_booking_box', 'd365_booking');
});

function d365_session_box(WP_Post $post): void {
    wp_nonce_field('d365_save_session', 'd365_session_nonce');
    $date = get_post_meta($post->ID, '_d365_date', true);
    $end_date = get_post_meta($post->ID, '_d365_end_date', true);
    $english = get_post_meta($post->ID, '_d365_en', true);
    $availability = get_post_meta($post->ID, '_d365_availability', true);
    $service = get_post_meta($post->ID, '_d365_service', true);
    $icon = d365_session_icon($post->ID);
    ?>
    <p><label for="d365_date">開始日（日本時間）</label><br><input type="date" id="d365_date" name="d365_date" value="<?= esc_attr($date) ?>"></p>
    <p><label for="d365_end_date">終了日（日本時間・任意）</label><br><input type="date" id="d365_end_date" name="d365_end_date" value="<?= esc_attr($end_date) ?>" aria-describedby="d365_end_date_help"></p>
    <p class="description" id="d365_end_date_help">1日開催の場合は終了日を空欄にしてください。複数日開催の場合は、終了日までがひとつの予約日程になります。</p>
    <p><label for="d365_en">英語でのイベント名</label><br><input class="widefat" id="d365_en" name="d365_en" value="<?= esc_attr($english) ?>"></p>
    <p><label for="d365_service">コース</label><br><select id="d365_service" name="d365_service">
        <?php foreach (d365_services() as $key => $label): ?>
            <option value="<?= esc_attr($key) ?>" <?php selected($service, $key); ?>><?= esc_html($label) ?></option>
        <?php endforeach; ?>
    </select></p>
    <p><label for="d365_availability">予約受付</label><br><select id="d365_availability" name="d365_availability">
        <option value="closed" <?php selected($availability !== 'open'); ?>>受付終了</option>
        <option value="open" <?php selected($availability, 'open'); ?>>受付中</option>
    </select></p>
    <fieldset class="d365-session-icons" aria-describedby="d365_session_icon_help">
        <legend>日程一覧のアイコン</legend>
        <p class="description" id="d365_session_icon_help">開催日程一覧で、ツアー名の左に表示されます。</p>
        <div class="d365-session-icon-options">
            <?php foreach (d365_session_icons() as $key => $label): ?>
                <label>
                    <input type="radio" name="d365_session_icon" value="<?= esc_attr($key) ?>" <?php checked($icon, $key); ?>>
                    <img src="<?= esc_url(d365_session_icon_url($key)) ?>" width="28" height="28" alt="">
                    <span><?= esc_html($label) ?></span>
                </label>
            <?php endforeach; ?>
        </div>
    </fieldset>
    <?php
}

add_action('save_post_d365_session', static function (int $id, WP_Post $post): void {
    if (wp_is_post_revision($id) || wp_is_post_autosave($id) || !current_user_can('edit_post', $id)
        || !wp_verify_nonce(d365_input($_POST, 'd365_session_nonce'), 'd365_save_session')) {
        return;
    }
    $date = d365_input($_POST, 'd365_date');
    $end_date = array_key_exists('d365_end_date', $_POST)
        ? d365_input($_POST, 'd365_end_date')
        : (string) get_post_meta($id, '_d365_end_date', true);
    $service = d365_input($_POST, 'd365_service');
    if (($date === '' ? $post->post_status === 'publish' : !d365_date($date))
        || ($end_date !== '' && ($date === '' || !d365_date($end_date) || $end_date < $date))) {
        add_filter('redirect_post_location', static fn (string $url): string =>
            add_query_arg('d365_invalid_period', '1', remove_query_arg('message', $url)));
        return;
    }
    update_post_meta($id, '_d365_date', $date);
    update_post_meta($id, '_d365_end_date', $end_date);
    update_post_meta($id, '_d365_en', sanitize_text_field(d365_input($_POST, 'd365_en')));
    update_post_meta($id, '_d365_service', array_key_exists($service, d365_services()) ? $service : 'trial');
    update_post_meta($id, '_d365_availability', d365_input($_POST, 'd365_availability') === 'open' ? 'open' : 'closed');
    $icon = d365_input($_POST, 'd365_session_icon');
    if (isset(d365_session_icons()[$icon])) {
        update_post_meta($id, '_d365_session_icon', $icon);
    }
}, 10, 2);

add_action('admin_notices', static function (): void {
    if (get_current_screen()?->post_type === 'd365_session' && d365_input($_GET, 'd365_invalid_period') === '1') {
        echo '<div class="notice notice-error"><p>開催日程の設定を保存できませんでした。開始日を入力し、終了日は開始日以降に設定してください。</p></div>';
    }
});

function d365_booking_box(WP_Post $post): void {
    wp_nonce_field('d365_save_booking', 'd365_booking_nonce');
    $labels = [
        'name' => 'お名前', 'email' => 'メール', 'people' => '人数',
        'session_title' => '申込時の日程名', 'session_date' => '開催期間・希望日', 'service' => 'ご相談内容',
        'tour_location' => '行ってみたい場所',
        'language' => '言語', 'message' => '連絡事項',
    ];
    ?>
    <dl>
        <?php foreach ($labels as $key => $label):
            $value = $key === 'session_date' ? d365_booking_period($post->ID) : (string) get_post_meta($post->ID, '_d365_' . $key, true);
            if (($key === 'tour_location' || $key === 'people') && $value === '') { continue; }
            ?>
            <dt><strong><?= esc_html($label) ?></strong></dt>
            <dd><?= nl2br(esc_html($key === 'service' ? (d365_inquiry_topics(false)[$value] ?? $value) : $value)) ?></dd>
        <?php endforeach; ?>
    </dl>
    <p><label for="d365_status">対応状況</label><br><select id="d365_status" name="d365_status">
        <?php foreach (d365_statuses() as $key => $label): ?>
            <option value="<?= esc_attr($key) ?>" <?php selected(get_post_meta($post->ID, '_d365_status', true), $key); ?>><?= esc_html($label) ?></option>
        <?php endforeach; ?>
    </select></p>
    <h3>自動メール</h3>
    <ul>
        <?php foreach (['received' => 'お客様への受付メール', 'staff' => '店舗への新着通知', 'confirmed' => '確定のご案内', 'declined' => '受付不可のご案内', 'cancelled' => 'キャンセルのご案内'] as $kind => $label): ?>
            <?php $result = (string) get_post_meta($post->ID, '_d365_mail_' . $kind, true); ?>
            <?php if ($result !== ''): ?>
                <li><?= esc_html($label) ?> · <?= esc_html($result === 'sent' ? '送信処理済み' : '送信失敗') ?></li>
            <?php endif; ?>
        <?php endforeach; ?>
    </ul>
    <?php
}

add_action('save_post_d365_booking', static function (int $id): void {
    if (!current_user_can('edit_post', $id) || wp_is_post_revision($id) || wp_is_post_autosave($id)
        || !wp_verify_nonce(d365_input($_POST, 'd365_booking_nonce'), 'd365_save_booking')) {
        return;
    }
    $status = d365_input($_POST, 'd365_status');
    $previous = get_post_meta($id, '_d365_status', true);
    if (isset(d365_statuses()[$status]) && $status !== $previous
        && update_post_meta($id, '_d365_status', $status, $previous) && $status !== 'pending') {
        d365_send_booking_mail($id, $status);
    }
});

add_filter('manage_d365_booking_posts_columns', static function (array $columns): array {
    return array_merge(array_diff_key($columns, ['date' => true]), ['session' => '開催日程', 'status' => '対応状況', 'date' => '受信日']);
});
add_action('manage_d365_booking_posts_custom_column', static function (string $column, int $id): void {
    if ($column === 'session') {
        echo esc_html(trim(d365_booking_period($id) . ' ' . get_post_meta($id, '_d365_session_title', true)));
    } elseif ($column === 'status') {
        $status = get_post_meta($id, '_d365_status', true);
        echo esc_html(d365_statuses()[$status] ?? '未対応');
    }
}, 10, 2);
add_filter('manage_d365_session_posts_columns', static function (array $columns): array {
    return array_merge(array_diff_key($columns, ['date' => true]), ['session_date' => '開催期間', 'availability' => '予約受付']);
});
add_action('manage_d365_session_posts_custom_column', static function (string $column, int $id): void {
    if ($column === 'session_date') {
        [$start, $end] = d365_session_dates($id);
        if ($start) {
            echo esc_html($start->format('Y-m-d') . ($end > $start ? ' – ' . $end->format('Y-m-d') : ''));
        }
    } elseif ($column === 'availability') {
        echo d365_session_open(get_post($id)) ? '受付中' : '受付終了';
    }
}, 10, 2);

add_action('admin_post_nopriv_d365_book', 'd365_submit_booking');
add_action('admin_post_d365_book', 'd365_submit_booking');
function d365_booking_feedback(string $result, bool $english, bool $other = false): string {
    if ($result === 'received' && $other) {
        return $english ? 'We received your inquiry. Our team will be in touch.' : 'お問い合わせを受け付けました。スタッフからのご連絡をお待ちください。';
    }
    $messages = [
        'received' => ['予約リクエストを受け付けました。スタッフからのご連絡をお待ちください。', 'We received your request. Our team will contact you to confirm availability.'],
        'invalid' => ['入力内容を確認して、もう一度お試しください。', 'Please check your details and try again.'],
        'closed' => ['この日程は受付を終了しました。別の日程をお選びください。', 'This session is closed. Please select another date.'],
        'error' => ['送信できませんでした。時間をおいて再度お試しください。', 'Your request could not be saved. Please try again shortly.'],
    ];
    return $messages[$result][$english ? 1 : 0] ?? '';
}

function d365_submit_booking(): void {
    $english = d365_input($_POST, 'language') === 'en';
    $result = d365_record_booking($_POST, $english);
    $other = d365_input($_POST, 'session') === '' && d365_input($_POST, 'service') === 'other';
    if (d365_input($_POST, 'd365_response') === 'json') {
        wp_send_json(['result' => $result, 'message' => d365_booking_feedback($result, $english, $other)]);
    }
    $args = ['booking' => $result];
    if ($other) {
        $args['dive_service'] = 'other';
    }
    wp_safe_redirect(d365_home($english, $args) . '#booking', 303);
    exit;
}

function d365_record_booking(array $input, bool $english): string {
    if (!wp_verify_nonce(d365_input($input, 'd365_nonce'), 'd365_book')
        || d365_input($input, 'company') !== '') {
        return 'invalid';
    }

    $session = d365_input($input, 'session');
    $service = d365_input($input, 'service');
    // Earlier copies of the form may still submit a preferred date.
    $date = d365_input($input, 'preferred_date');
    $end_date = '';
    $event = null;
    if ($session !== '') {
        $event = d365_open_booking_session($session);
        if (!$event) {
            return 'closed';
        }
        $service = (string) get_post_meta($event->ID, '_d365_service', true);
        [$start, $end] = d365_session_dates($event->ID);
        $date = $start->format('Y-m-d');
        $end_date = $end->format('Y-m-d');
    }
    $topics = $event ? d365_services($english) : d365_inquiry_topics($english);
    if (!isset($topics[$service]) || ($date !== '' && (!d365_date($date) || $date < d365_now()->format('Y-m-d')))) {
        return 'invalid';
    }

    $name = sanitize_text_field(d365_input($input, 'guest_name'));
    $raw_email = trim(d365_input($input, 'guest_email'));
    $email = sanitize_email($raw_email);
    $other = $service === 'other';
    $people = $other ? '' : filter_var(d365_input($input, 'people'), FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 10]]);
    $message = sanitize_textarea_field(d365_input($input, 'message'));
    $tour_location = $service === 'tour' ? sanitize_text_field(d365_input($input, 'tour_location')) : '';
    if ($name === '' || strlen($name) > 400 || !is_email($email) || $email !== $raw_email || strlen($email) > 254
        || (!$other && !$people) || strlen($message) > 4000 || strlen($tour_location) > 400 || d365_input($input, 'consent') !== '1') {
        return 'invalid';
    }

    $event_en = $event ? (string) get_post_meta($event->ID, '_d365_en', true) : '';
    $booking = wp_insert_post([
        'post_type' => 'd365_booking', 'post_status' => 'private', 'post_title' => ($other ? 'お問い合わせ ' : '予約申請 ') . wp_generate_uuid4(),
        'meta_input' => [
            '_d365_name' => $name, '_d365_email' => $email, '_d365_people' => $people,
            '_d365_message' => $message, '_d365_language' => $english ? 'English' : '日本語',
            '_d365_tour_location' => wp_slash($tour_location),
            '_d365_session' => $event->ID ?? 0, '_d365_session_title' => $english && $event_en !== '' ? $event_en : ($event->post_title ?? ''),
            '_d365_session_date' => $date, '_d365_session_end_date' => $end_date,
            '_d365_service' => $service, '_d365_status' => 'pending',
        ],
    ], true);
    if (!$booking || is_wp_error($booking)) {
        return 'error';
    }
    d365_send_booking_mail($booking, 'received');
    d365_send_booking_mail($booking, 'staff');
    return 'received';
}

function d365_show_booking(): void {
    require __DIR__ . '/calendar.php';
}
