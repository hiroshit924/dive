<?php
defined('ABSPATH') || exit;

$english = d365_is_english();
$today = d365_now();
$current = $today->modify('first day of this month')->setTime(0, 0);
$selected = d365_date(d365_input($_GET, 'dive_month'), 'Y-m');
$first = $selected && $selected >= $current && $selected <= $current->modify('+12 months') ? $selected : $current;
$month = $first->format('Y-m');
$last = $first->modify('last day of this month');
$sessions = d365_sessions($first->format('Y-m-d'), $last->format('Y-m-d'));
$requested_session = d365_input($_GET, 'dive_session');
$chosen_session = d365_open_booking_session($requested_session);
$preferred_service = $chosen_session ? (string) get_post_meta($chosen_session->ID, '_d365_service', true) : d365_input($_GET, 'dive_service');
$show_tour_location = $preferred_service === 'tour';
$days = $english ? ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'] : ['月', '火', '水', '木', '金', '土', '日'];
$days_with_sessions = [];
$open_by_day = [];
foreach ($sessions as $session) {
    $day = (int) substr(get_post_meta($session->ID, '_d365_date', true), -2);
    $days_with_sessions[$day] = true;
    if (d365_session_open($session)) {
        $open_by_day[$day][] = $session->ID;
    }
}
$session_link = static fn (int $id): string => d365_home($english, ['dive_month' => $month, 'dive_session' => $id]) . '#booking';
$result = d365_input($_GET, 'booking');
if ($result === '' && $requested_session !== '' && !$chosen_session) {
    $result = 'closed';
}
?>
<section id="calendar" class="section calendar">
    <div class="wrap">
        <h2><?= esc_html(d365_text('ダイビングカレンダー', 'Dive calendar')) ?></h2>
        <div class="schedule-grid">
            <div class="calendar-card">
                <div class="month-nav">
                    <?php if ($first > $current): ?>
                        <a aria-label="<?= esc_attr(d365_text('前の月', 'Previous month')) ?>" href="<?= esc_url(d365_home($english, ['dive_month' => $first->modify('-1 month')->format('Y-m')]) . '#calendar') ?>">←</a>
                    <?php else: ?><span></span><?php endif; ?>
                    <strong><?= esc_html($first->format($english ? 'F Y' : 'Y年n月')) ?></strong>
                    <?php if ($first < $current->modify('+12 months')): ?>
                        <a aria-label="<?= esc_attr(d365_text('次の月', 'Next month')) ?>" href="<?= esc_url(d365_home($english, ['dive_month' => $first->modify('+1 month')->format('Y-m')]) . '#calendar') ?>">→</a>
                    <?php else: ?><span></span><?php endif; ?>
                </div>
                <table>
                    <caption class="screen-reader-text"><?= esc_html($first->format($english ? 'F Y' : 'Y年n月')) ?></caption>
                    <thead><tr><?php foreach ($days as $day): ?><th scope="col"><?= esc_html($day) ?></th><?php endforeach; ?></tr></thead>
                    <tbody>
                    <?php $offset = (int) $first->format('N') - 1;
                    $total = (int) $last->format('j');
                    for ($week = 0; $week < (int) ceil(($total + $offset) / 7); $week++): ?>
                        <tr><?php for ($col = 0; $col < 7; $col++):
                            $day = $week * 7 + $col - $offset + 1; ?>
                            <td><?php if ($day >= 1 && $day <= $total):
                                if (isset($days_with_sessions[$day])):
                                    $available_today = $open_by_day[$day] ?? [];
                                    $direct = count($available_today) === 1;
                                    $label = $first->setDate((int) $first->format('Y'), (int) $first->format('n'), $day)->format($english ? 'F j' : 'n月j日');
                                    $label .= ' · ' . ($direct
                                        ? d365_text('参加をリクエスト', 'Request a spot')
                                        : d365_text('開催日程を見る', 'View sessions'));
                                    ?>
                                    <a class="<?= $available_today ? 'calendar-day-open' : 'calendar-day-closed' ?>" href="<?= esc_url($direct ? $session_link($available_today[0]) : '#dives-' . $day) ?>" aria-label="<?= esc_attr($label) ?>"><?= esc_html((string) $day) ?></a>
                                <?php elseif ($first->format('Y-m') === $today->format('Y-m') && $day === (int) $today->format('j')): ?>
                                    <span aria-current="date"><?= esc_html((string) $day) ?></span>
                                <?php else: echo esc_html((string) $day); endif;
                            endif; ?></td>
                        <?php endfor; ?></tr>
                    <?php endfor; ?>
                    </tbody>
                </table>
                <?php if ($open_by_day): ?>
                    <p class="calendar-legend"><?= esc_html(d365_text('青い日付から参加をリクエストできます。', 'Select a blue date to request a spot.')) ?></p>
                <?php endif; ?>
            </div>
            <div class="calendar-schedule">
                <h3><?= esc_html(d365_text('今月の開催日程', 'Sessions this month')) ?></h3>
                <?php if (!$sessions): ?><p><?= esc_html(d365_text('この月の開催日程はまだ掲載されていません。', 'No sessions have been posted for this month.')) ?></p><?php endif; ?>
                <?php $previous_day = 0; foreach ($sessions as $session):
                    $date = d365_date((string) get_post_meta($session->ID, '_d365_date', true));
                    if (!$date) { continue; }
                    $day = (int) $date->format('j');
                    $service = d365_services()[get_post_meta($session->ID, '_d365_service', true)] ?? '';
                    ?>
                    <article class="session-item" <?php if ($day !== $previous_day): ?>id="dives-<?= esc_attr((string) $day) ?>"<?php endif; ?>>
                        <div><time datetime="<?= esc_attr($date->format('Y-m-d')) ?>"><?= esc_html($date->format($english ? 'M j' : 'n月j日')) ?></time>
                        <strong><?= esc_html(d365_session_title($session)) ?></strong>
                        <small><?= esc_html($service) ?></small></div>
                        <?php if (d365_session_open($session)): ?>
                            <a href="<?= esc_url($session_link($session->ID)) ?>"><?= esc_html(d365_text('参加をリクエスト', 'Request a spot')) ?></a>
                        <?php else: ?><span><?= esc_html(d365_text('受付終了', 'Closed')) ?></span><?php endif; ?>
                    </article>
                    <?php $previous_day = $day; ?>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<section class="section booking" id="booking">
    <div class="wrap booking-grid">
        <div>
            <h2><?= esc_html(d365_text('ダイビングを予約', 'Request a dive')) ?></h2>
            <p><?= esc_html(d365_text('カレンダーの日程から参加を申し込むか、ご相談内容をお知らせください。スタッフが確認し、ご連絡します。', 'Request a spot from the calendar or tell us what you’d like to discuss. Our team will follow up to confirm your booking.')) ?></p>
            <p><a href="tel:+81452735496">045-273-5496</a></p>
        </div>
        <div>
                <form class="d365-booking-form" method="post" action="<?= esc_url(admin_url('admin-post.php')) ?>" data-submit-error="<?= esc_attr(d365_text('送信結果を確認できませんでした。再送する前にショップへお問い合わせください。', 'We couldn’t verify the result. Contact the shop before sending another request.')) ?>">
                    <input type="hidden" name="action" value="d365_book">
                    <input type="hidden" name="language" value="<?= $english ? 'en' : 'ja' ?>">
                    <?php wp_nonce_field('d365_book', 'd365_nonce', false); ?>
                    <div hidden aria-hidden="true"><label>Company <input type="text" name="company" tabindex="-1" autocomplete="off"></label></div>
                    <?php if ($chosen_session):
                        $chosen_date = d365_date((string) get_post_meta($chosen_session->ID, '_d365_date', true)); ?>
                        <input type="hidden" name="session" value="<?= esc_attr((string) $chosen_session->ID) ?>">
                        <p class="booking-session">
                            <time datetime="<?= esc_attr($chosen_date->format('Y-m-d')) ?>"><?= esc_html($chosen_date->format($english ? 'M j, Y' : 'Y年n月j日')) ?></time>
                            · <strong><?= esc_html(d365_session_title($chosen_session)) ?></strong>
                            <a href="<?= esc_url(d365_home($english, ['dive_month' => $month]) . '#calendar') ?>"><?= esc_html(d365_text('日程を選び直す', 'Change date')) ?></a>
                        </p>
                    <?php endif; ?>
                    <label for="d365_service"><?= esc_html(d365_text('ご相談内容', 'Inquiry topic')) ?></label>
                    <select id="d365_service" name="service" <?= $chosen_session ? 'disabled' : 'required' ?>>
                        <option value=""><?= esc_html(d365_text('ご相談内容を選んでください', 'Select a topic')) ?></option>
                        <?php foreach (d365_services() as $key => $label): ?>
                            <option value="<?= esc_attr($key) ?>" <?php selected($preferred_service, $key); ?>><?= esc_html($label) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <div class="booking-tour-location" <?= $show_tour_location ? '' : 'hidden' ?>>
                        <label for="d365_tour_location"><?= esc_html(d365_text('行ってみたい場所（任意）', 'Where would you like to dive? (optional)')) ?></label>
                        <input id="d365_tour_location" name="tour_location" maxlength="100" value="<?= esc_attr($show_tour_location ? apply_filters('d365_booking_tour_location_default', '') : '') ?>" <?= $show_tour_location ? '' : 'disabled' ?>>
                    </div>
                    <label for="d365_guest_name"><?= esc_html(d365_text('お名前', 'Name')) ?></label>
                    <input id="d365_guest_name" name="guest_name" maxlength="100" autocomplete="name" required>
                    <label for="d365_guest_email"><?= esc_html(d365_text('メールアドレス', 'Email address')) ?></label>
                    <input id="d365_guest_email" type="email" name="guest_email" maxlength="254" autocomplete="email" required>
                    <label for="d365_people"><?= esc_html(d365_text('参加人数', 'Number of guests')) ?></label>
                    <input id="d365_people" type="number" name="people" value="1" min="1" max="10" required>
                    <label for="d365_message"><?= esc_html(d365_text('連絡事項（任意）', 'Additional notes (optional)')) ?></label>
                    <textarea id="d365_message" name="message" rows="3" maxlength="1000" aria-describedby="d365_notes_help"><?= esc_textarea(apply_filters('d365_booking_notes_default', '')) ?></textarea>
                    <small id="d365_notes_help"><?= esc_html(d365_text('健康情報の記入はお控えください。', 'Please leave out any medical information.')) ?></small>
                    <label class="consent"><input type="checkbox" name="consent" value="1" required>
                        <span><?= esc_html(d365_text('入力した情報を予約対応と連絡に使用することに同意します。', 'I agree that my details may be used to handle my request and contact me about it.')) ?>
                            <?php if (get_privacy_policy_url()): ?> <a href="<?= esc_url(get_privacy_policy_url()) ?>"><?= esc_html(d365_text('プライバシーポリシー', 'Privacy policy')) ?></a><?php endif; ?>
                        </span>
                    </label>
                    <p class="form-notice <?= $result === 'received' ? 'success' : 'error' ?>" role="status" tabindex="-1"><?= esc_html(d365_booking_feedback($result, $english)) ?></p>
                    <button class="button" type="submit"><?= esc_html(d365_text('予約リクエストを送信', 'Send booking request')) ?> <span aria-hidden="true">→</span></button>
                </form>
        </div>
    </div>
</section>
